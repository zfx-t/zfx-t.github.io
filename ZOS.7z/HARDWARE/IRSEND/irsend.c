#include "irsend.h"
#include "delay.h"

// 红外发射模块初始化
void IRsendInit()
{
	//**硬件初始化
	RCC->APB2ENR |= 1 << 4; // 使能PORTC时钟

	GPIOC->CRH &= 0xFFF0FFFF;
	GPIOC->CRH |= 0x00030000; // PC.12推挽输出
	GPIOC->ODR |= 0x00001000; // PC.12输出高  	//端口输出高？
}
int t;
int data[67] =
	{1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1};
 void TR_SendData()
{
	// 引导码
	Send_H_delay(338);

	Send_L_delay(170);

	// 数据
	for (t = 0; t < 35; t++)
	{

		Send_H_delay(22);

		if (data[t])
		{
			Send_L_delay(60);
		}
		else
		{
			Send_L_delay(22);
		}
	}
	// 连接码
	// 引导码
	Send_H_delay(22);

	Send_L_delay(770);
	// 第二段数据
	for (t = 0; t < 32; t++)
	{
		Send_H_delay(22);

		if (data[35 + t])
		{
			Send_L_delay(60);
		}
		else
		{
			Send_L_delay(22);
		}
	}
	// 发送结束码
	Send_H_delay(22);
	Send_L_delay(22);
}

void Send_H_delay(int time)
{
	int i;
	for (i = 0; i < time; i++)
	{
		IR_SEND = 1;
		delay_us(13);
		IR_SEND = 0;
		delay_us(13);
	}
}
void Send_L_delay(int time)
{

	int i;
	for (i = 0; i < time; i++)
	{

		IR_SEND = 0;
		delay_us(26);
	}
}