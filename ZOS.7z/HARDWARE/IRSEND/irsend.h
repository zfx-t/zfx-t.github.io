#include "sys.h"

#define IR_SEND PCout(12)

void IRsendInit();


/**
* 发送标准的32位NEC数据
*
* @param data 32位要发送的数据
*/
void TR_SendData();

void Send_H_delay(int time);
void Send_L_delay(int time);
void IR_ControlPower(int on_off);