/******************************流水灯************************
* 流水灯
* 现象：二极管从左至右依次点亮
*************************************************************/

#include "sys.h"
#include "delay.h"
#include "led.h"
#include "key.h"
#include "remote.h"
#include "usart.h"
#include "irsend.h"
void uartTask(){
		u8 t;
		u8 len;	
		u16 times=0;  
		if(USART_RX_STA&0x80)
		{					   
			len=USART_RX_STA&0x3f;//????????????
			printf("\n Your MSG: ");
			USART_RX_BUF[len]='\0';
			printf("%s",USART_RX_BUF);
			//可以操作的地方
			printf("\n\n");//????
			
			USART_RX_STA=0;
		}
}

void SystemInit(void)
{
	Stm32_Clock_Init( 9 );  //9倍频，8M外部晶振
	delay_init( 72 );     //系统时钟72MHz
	LED_Init();
	KeyInit();
	IRsendInit();
	uart_init(72,115200);
	Remote_Init();
}
u8 key;
int main( void )
{
	SystemInit();
	
	//LED_SEL = 1; //选择二极管
	LED_SEL = 0;
	
	while( 1 )
	{
		uartTask();
	
		if(KeyScan()==1){
			
			Remote_OFF();
			delay_ms(200);
			TR_SendData();
			delay_ms(100);
			Remote_ON();
			
		}
		if(KeyScan()==2){
			print_remote();
		}
		
	}	 
	
	
}

